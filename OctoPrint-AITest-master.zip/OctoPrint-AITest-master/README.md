# OctoPrint-MultiColors

Octoprint plugin to inject GCODE for filament change at selected layers

Note: this plugin does NOT work with files on the SD card.

![screenshot](screenshot_1.png)


### Setup

Install via the bundled Plugin Manager or manually using this URL:

https://github.com/MoonshineSG/Octoprint-MultiColors/archive/master.zip

### Donate

Accepting [beer tips](https://paypal.me/ovidiuhossu)...
